import java.util.ArrayList;

public class Query {
	Atom head;
	ArrayList<Atom> body = new ArrayList<Atom>();
	ArrayList<String> SharedVar = new ArrayList<String>();
	ArrayList<String> constant = new ArrayList<String>();

	/* This function returns the constants that are present in the Query. */
	public static ArrayList<String> getConstants(ArrayList<String> vars) {
		ArrayList<String> constants = new ArrayList<>();
		for (String term : vars) {
			if (!Character.isUpperCase(term.charAt(0)) && term.length() >= 1) {
				constants.add(term);
			}
		}
		return constants;
	}

	/*
	 * This function checks whether or not a string is a Variable. Variables use
	 * capital letters.
	 */
	public static boolean isVariable(String str) {
		return !str.contains("(") && !str.contains("Ex0") && (str.charAt(0) >= 'A' && str.charAt(0) <= 'Z');
	}

	/*
	 * This is the constructor that creates an object query, given as a string the
	 * head part of the query, and another string the body part of the query.
	 */
	public Query(String head, String body) {
		int beginindex = 0;
		for (int i = 0; i < body.length() - 1; i++) {
			if (body.charAt(i) == ')' && body.charAt(i + 1) == ',') {
				String subbody = body.substring(beginindex, i + 1);
				Atom bod = new Atom(subbody);
				this.constant.addAll(getConstants(bod.Variables));
				beginindex = i + 2;
				this.body.add(bod);
			} else if (i + 2 == body.length()) {
				String subbody = body.substring(beginindex, body.length());
				Atom bod = new Atom(subbody);
				this.constant.addAll(getConstants(bod.Variables));
				this.body.add(bod);
			}
		}
		this.head = new Atom(head);

		for (int i = 0; i < this.body.size(); i++) {
			for (int j = 0; j < this.body.get(i).Variables.size(); j++) {
				if (this.head.Variables.contains(this.body.get(i).Variables.get(j))
						&& !this.SharedVar.contains(this.body.get(i).Variables.get(j))
						&& isVariable(this.body.get(i).Variables.get(j)))
					this.SharedVar.add(this.body.get(i).Variables.get(j));
			}
			if (i != this.body.size() - 1) {
				int j = i + 1;
				while (j <= this.body.size() - 1) {
					for (int k = 0; k < this.body.get(j).Variables.size(); k++) {
						if (this.body.get(i).Variables.contains(this.body.get(j).Variables.get(k))
								&& !this.SharedVar.contains(this.body.get(j).Variables.get(k))
								&& isVariable(this.body.get(j).Variables.get(k)))
							this.SharedVar.add(this.body.get(j).Variables.get(k));
					}
					j++;
				}
			}
		}

	}

}
