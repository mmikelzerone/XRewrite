import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class XRewriteEliminate {
	static ArrayList<Edge> PG = new ArrayList<Edge>();

	/*
	 * This function checks whether or not a string is a Variable. Variables use
	 * capital letters.
	 */
	public static boolean isVariable(String str) {
		return !str.contains("(") && (str.charAt(0) >= 'A' && str.charAt(0) <= 'Z');
	}

	/*
	 * This function prints the propagation graph, it is not used oin the main
	 * algorithm, it exists if someone wants to obtain the propagation graph.
	 */
	public static void printGraph(ArrayList<Edge> PG) {
		for (int i = 0; i < PG.size(); i++) {
			System.out.println(PG.get(i).node1 + " ---------> " + PG.get(i).node2 + " with tgd: " + PG.get(i).tgd);
		}
	}

	/*
	 * This function returns all the indexes of an item that is contained in an
	 * arraylist.
	 */
	public static List<Integer> getAllIndexes(ArrayList<String> list, String item) {
		List<Integer> indexes = IntStream.range(0, list.size()).filter(k -> list.get(k).equals(item)).boxed()
				.collect(Collectors.toList());
		return indexes;
	}

	/*
	 * This is the constructor of the query elimination technique, and it constructs
	 * the propagation graph, given a set of ontology containing ontology rules.
	 */
	public XRewriteEliminate(ArrayList<TGD> ontology) {
		for (int i = 0; i < ontology.size(); i++) {
			TGD aux = new TGD(ontology.get(i).body.toString(), ontology.get(i).head.toString());
			for (int j = 0; j < ontology.get(i).body.Variables.size(); j++) {
				String bodyvar = ontology.get(i).body.Variables.get(j);
				if (isVariable(bodyvar) && ontology.get(i).head.Variables.contains(bodyvar)) {
					List<Integer> indexes = getAllIndexes(aux.head.Variables, bodyvar);
					for (int k = 0; k < indexes.size(); k++) {
						Edge edg = new Edge(ontology.get(i).body.name + "[" + (j + 1) + "]",
								ontology.get(i).head.name + "[" + (indexes.get(k) + 1) + "]",
								ontology.get(i).toString());
						PG.add(edg);
					}

				}

			}
		}
	}

	/* An empty constructor. */
	public XRewriteEliminate() {

	}
	/*
	 * This function homomorphically maps the variables from atom t_1 to atom t_2
	 */
	public static ArrayList<String> unify(Atom t_1, Atom t_2) {
		if (t_1.name.equals(t_2.name) && t_1.Variables.size() == t_2.Variables.size()) {
			ArrayList<String> VariableMatching = new ArrayList<String>();
			for (int w = 0; w < t_1.Variables.size(); w++) {
				VariableMatching.add(t_1.Variables.get(w) + "/" + t_2.Variables.get(w));
			}
			return VariableMatching;
		} else
			return null;
	}

	/* This function returns the key of a specific value contained in a hashmap. */
	public static String getKeyByValue(HashMap<String, String> map, String value) {
		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (entry.getValue().equals(value)) {
				return entry.getKey();
			}
		}
		return null; // value not found in map
	}

	/*
	 * This function checks if a path, that is implemented and encoded into an
	 * arraylist, is tight and compatible to an atom a.
	 */
	public static boolean isTightandCompatible(ArrayList<String> S) {
		for (int i = 0; i < S.size() - 1; i = i + 2) {
			HashMap<String, String> ModuloBijectiveVariables = new HashMap<String, String>();
			ArrayList<String> homomorphisms = unify(new Atom(S.get(i)), new Atom(S.get(i + 1)));
			if (homomorphisms != null) {
				for (int f = 0; f < homomorphisms.size(); f++) {
					String[] parts = homomorphisms.get(f).split("\\s*/\\s*");
					String a = parts[0].trim();
					String b = parts[1].trim();
					if ((isVariable(a) && isVariable(b)) || (!isVariable(a) && !isVariable(b) && a.equals(b))) {
						if (!ModuloBijectiveVariables.containsKey(a)) {
							if (!ModuloBijectiveVariables.containsValue(b)) {
								ModuloBijectiveVariables.put(a, b);
							} else {
								String getKey = getKeyByValue(ModuloBijectiveVariables, b);
								if (!getKey.equals(a)) {
									return false;
								}
							}
						} else {
							if (!ModuloBijectiveVariables.get(a).equals(b)) {
								return false;
							}
						}
					} else {
						return false;
					}
				}

			} else
				return false;
		}

		return true;
	}

	/*
	 * This function checks if a path was traversed before. Returns true if it wa
	 * traversed.
	 */
	public static boolean traversedpaths(ArrayList<ArrayList<Edge>> paths, ArrayList<Edge> P) {
		for (int i = 0; i < paths.size(); i++) {
			boolean samepath = true;
			if (paths.get(i).size() == P.size()) {
				for (int j = 0; j < paths.get(i).size(); j++) {
					if (!(paths.get(i).get(j).node1.equals(P.get(j).node1)
							&& paths.get(i).get(j).node2.equals(P.get(j).node2)
							&& paths.get(i).get(j).tgd.equals(P.get(j).tgd))) {
						samepath = false;
						break;
					}
				}
				if (samepath)
					return true;
			}

		}
		return false;
	}

	/*
	 * This function calls the function minimal, and if the path is minimal, it
	 * proceeds to call the function istightandcompatible to check if it is tight
	 * and compatible to an atom a.
	 */
	public static boolean checkpath(ArrayList<Edge> P, Atom a) {
		ArrayList<String> nodes = new ArrayList<String>();
		nodes.add("");

		for (int i = 0; i < P.size(); i++) {
			nodes.add(P.get(i).node1);
			if (i == P.size() - 1)
				nodes.add(P.get(i).node2);
		}
		if (minimal(nodes)) {
			ArrayList<String> S = new ArrayList<String>();
			String[] parts1 = P.get(0).tgd.split(":-");
			String bodyPart1 = parts1[1].trim();
			S.add(bodyPart1);
			S.add(a.toString());
			for (int k = 0; k < P.size() - 1; k++) {
				String[] parts = P.get(k + 1).tgd.split(":-");
				String bodyPart = parts[1].trim();
				S.add(bodyPart);
				parts = P.get(k).tgd.split(":-");
				String headPart = parts[0].trim();
				S.add(headPart);
			}
			if (isTightandCompatible(S)) {
				return true;
			} else
				return false;
		} else
			return false;
	}

	/* This function checks if a path is minimal. */
	public static boolean minimal(ArrayList<String> path) {
		for (int i = 2; i < path.size() - 1; i++) {
			for (int j = 1; j < i; j++) {
				if (i + j <= path.size() - 1) {
					ArrayList<String> nodesA = new ArrayList<String>();
					ArrayList<String> nodesB = new ArrayList<String>();
					boolean minimalpath = false;
					int k = 0;
					while (k <= j) {
						nodesB.add(path.get(i + k));
						k++;
					}
					k--;
					while (k >= 0) {
						nodesA.add(path.get(i - k));
						k--;
					}
					for (int l = 0; l < nodesA.size(); l++) {
						if (!nodesA.get(l).equals(nodesB.get(l)))
							minimalpath = true;
					}
					if (!minimalpath)
						return false;
				}
			}
		}
		return true;
	}

	/*
	 * This function below implements the DFS algorithm to search if there is a path
	 * S of TGDs, that propagate a term from position p1 from atom a to a position
	 * p2 from atom b.
	 */
	public static boolean searchgraph(String posa, String posb, ArrayList<Edge> P, ArrayList<String> visited, Atom a,
			ArrayList<ArrayList<Edge>> allpaths) {
		visited.add(posa);

		if (posa.equals(posb) && !traversedpaths(allpaths, P)) {
			if (P.isEmpty())
				return false;
			allpaths.add(P);
			if (checkpath(P, a)) {
				return true;
			} else
				return false;
		}

		for (int i = 0; i < PG.size(); i++) {
			if (PG.get(i).node1.equals(posa)) {
				if (!visited.contains(PG.get(i).node2)) {
					P.add(PG.get(i));
					if (searchgraph(PG.get(i).node2, posb, P, visited, a, allpaths)) {
						return true;
					}
					P.remove(P.size() - 1);
				}
			}
		}
		return false;
	}

	/* This function is used to verify a path from p1 to p2. */
	public static String findingraph(String tgd, String node) {

		for (int i = 0; i < PG.size(); i++)
			if (PG.get(i).node1.equals(node) && PG.get(i).tgd.equals(tgd))
				return PG.get(i).node2;
		return "not found";

	}

	/* This function is used to verify a path from p1 to p2. */
	public static String findingraph(String tgd, String node, String targetnode) {

		for (int i = 0; i < PG.size(); i++)
			if (PG.get(i).node1.equals(node) && PG.get(i).tgd.equals(tgd) && PG.get(i).node2.equals(targetnode))
				return PG.get(i).node2;
		return "not found";

	}

	/*
	 * This function is used to initiate all the functions mentioned above, in order
	 * to determine whether there is a valid path (tight, minimal, compatible to an
	 * atom a). Returns the final path.
	 */
	public static ArrayList<Edge> findPath(String posa, String posb, Atom a, Atom b,
			ArrayList<ArrayList<Edge>> allpaths) {
		ArrayList<Edge> P = new ArrayList<Edge>();
		ArrayList<String> visited = new ArrayList<String>();
		boolean pathexists = searchgraph(posa, posb, P, visited, a, allpaths);
		if (pathexists)
			return P;
		else
			return null;
	}

	/*
	 * This function checks whether atom a covers atom b. Returns true if a covers
	 * b.
	 */
	public static boolean covers(Query q, Atom a, Atom b) {
		boolean flag = true;
		boolean breakflag = true;
		ArrayList<String> T = new ArrayList<>();
		ArrayList<ArrayList<Edge>> allpaths = new ArrayList<ArrayList<Edge>>();
		for (int i = 0; i < b.Variables.size(); i++) {
			if (q.constant.contains(b.Variables.get(i)) || q.SharedVar.contains(b.Variables.get(i))) {
				if (!T.contains(b.Variables.get(i)))
					T.add(b.Variables.get(i));
			}
		}
		if (T.isEmpty())
			return false;
		if (!a.Variables.containsAll(T))
			return false;
		while (flag) {
			flag = false;
			breakflag = false;
			List<Integer> pos_a_t = getAllIndexes(a.Variables, T.get(0));
			List<Integer> pos_b_t = getAllIndexes(b.Variables, T.get(0));
			String posa = a.name + "[" + (pos_a_t.get(0) + 1) + "]";
			String posb = b.name + "[" + (pos_b_t.get(0) + 1) + "]";
			ArrayList<Edge> Path = findPath(posa, posb, a, b, allpaths);
			if (Path == null)
				return false;
			for (int i = 0; i < T.size(); i++) {
				pos_a_t = getAllIndexes(a.Variables, T.get(i));
				pos_b_t = getAllIndexes(b.Variables, T.get(i));
				for (int j = 0; j < pos_a_t.size(); j++)
					for (int k = 0; k < pos_b_t.size(); k++) {
						posa = a.name + "[" + (pos_a_t.get(j) + 1) + "]";
						posb = b.name + "[" + (pos_b_t.get(k) + 1) + "]";
						for (int w = 0; w < Path.size(); w++) {
							if (w == Path.size() - 1)
								posa = findingraph(Path.get(w).tgd, posa, posb);
							else
								posa = findingraph(Path.get(w).tgd, posa);
						}
						if (posa.equals("not found")) {
							flag = true;
							breakflag = true;
							break;
						}

					}
				if (breakflag)
					break;
			}
		}

		return true;

	}

	/* This is the main algorithm of Query Elimination optimization. */
	public static List<Integer> eliminateAlgorithm(Query q) {

		List<Integer> A = new ArrayList<Integer>();
		ArrayList<ArrayList<String>> coverSets = new ArrayList<ArrayList<String>>();
		for (int i = 0; i < q.body.size(); i++) {
			ArrayList<String> coveri = new ArrayList<String>();
			for (int j = 0; j < q.body.size(); j++) {
				if (i != j) {
					if (covers(q, q.body.get(j), q.body.get(i)))
						coveri.add(q.body.get(j).toString());
				}
			}
			coverSets.add(coveri);
		}
		for (int i = 0; i < q.body.size(); i++) {
			if (!coverSets.get(i).isEmpty()) {
				A.add(i);
				for (int j = 0; j < q.body.size(); j++) {
					if (!A.contains(j)) {
						coverSets.get(j).remove(q.body.get(i).toString());
					}
				}
			}
		}
		return A;
	}
}
