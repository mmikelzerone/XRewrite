import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class XRewrite {
	static ArrayList<TGD> ontology = new ArrayList<TGD>();
	static ArrayList<Query> queries = new ArrayList<Query>();
	public Query q;
	public boolean rewriting;
	private boolean explored;

	/*
	 * This constructor creates the trifold explained
	 * <q,rewrite/factorization,explored/unexplored>.
	 */
	public XRewrite(Query q, boolean rewriting, boolean explored) {
		this.q = q;
		this.rewriting = rewriting;
		this.explored = explored;
	}

	/*
	 * This function reads the Ontology file provided in the Command Line arguments.
	 */

	public static void readontology(String file) {
		String filename = file;

		try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
			String line = reader.readLine();
			while (line != null) {
				// process the line
				if (line.contains(":-")) {
					String[] parts = line.split(":-");
					if (parts.length == 2) {
						String headPart = parts[0].trim();
						String bodyPart = parts[1].trim();
						int comma_head = headPart.lastIndexOf(",");
						int closing_parenthesis_head = headPart.indexOf(")");
						int comma_body = bodyPart.lastIndexOf(",");
						int closing_parenthesis_body = bodyPart.indexOf(")");
						if (comma_head > closing_parenthesis_head) {
							// System.out.println("Invalid TGD: " + line);

						} else if (comma_body > closing_parenthesis_body) {
							// System.out.println("Invalid TGD: " + line);

						} else if (headPart.matches("^[^\\s]+\\(.+\\)$") && bodyPart.matches("^[^\\s]+\\(.+\\)$")) {
							// System.out.println(line);
							ontology.add(new TGD(bodyPart, headPart));
						}

					}
				}
				// Print the result

				line = reader.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/* This function reads the CQ provided in the Command Line arguments. */
	public static void readquery(String q) {
		if (q.contains(":-")) {
			String[] parts = q.split(":-");
			if (parts.length == 2) {
				String headPart = parts[0].trim();
				String bodyPart = parts[1].trim();
				int comma_head = headPart.lastIndexOf(",");
				int closing_parenthesis_head = headPart.indexOf(")");
				if (comma_head > closing_parenthesis_head) {
					System.out.println("Invalid Query: " + q);

				} else if (headPart.matches("^[^\\s]+\\(.+\\)$") && bodyPart.matches("^[^\\s]+\\(.+\\)$")) {
					queries.add(new Query(headPart, bodyPart));
				}

			}
		}

	}

	/*
	 * This function is used at the end of the algorithm for printing all the CQs
	 * that are part of the UCQs.
	 */
	public static String UCQ(ArrayList<Atom> atoms) {
		String body = "";
		for (int q = 0; q < atoms.size(); q++) {
			body += atoms.get(q).toString() + ", ";
		}
		return body.substring(0, body.length() - 2);
	}

	/*
	 * This function checks whether or not a string is a Variable. Variables use
	 * capital letters.
	 */
	public static boolean isVariable(String str) {

		return !str.contains("(") && !str.contains("Ex0") && (str.charAt(0) >= 'A' && str.charAt(0) <= 'Z');
	}

	/*
	 * This function checks whether or not a string is an Atom. An atom consists of
	 * the relation, and its attributes are enclosed by parenthesis. For example
	 * <relationname>(<term1>,<term2>,<term3>,...) The function returns true if it
	 * is of this form.
	 */
	public static boolean isAtom(String str) {
		return (str.contains("(") && str.contains(")"));
	}

	/*
	 * This function checks if an atom w.r.t to a TGD s is considered a candidate
	 * Atom to be added in a set of factorizable atoms.
	 */
	public static boolean candidateAtom(Atom atom, TGD s, Atom setAtom) {

		if (!atom.name.equals(s.head.name))
			return false;
		if (!atom.Variables.get(s.head.Variables.indexOf(s.ExistentiallyQuantifiedVar))
				.equals(setAtom.Variables.get(s.head.Variables.indexOf(s.ExistentiallyQuantifiedVar))))
			return false;
		return true;

	}

	/* This function returns the key of a specific value contained in a hashmap. */
	public static String getKeyByValue(HashMap<String, String> map, String value) {
		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (entry.getValue().equals(value)) {
				return entry.getKey();
			}
		}
		return null; // value not found in map
	}

	/*
	 * This function is used by Unify method. It essentially returns the
	 * substitutions for variables in a set of atoms.
	 */
	public static ArrayList<String> checkVariables(Atom t_1, Atom t_2) {
		if (t_1.name.equals(t_2.name) && t_1.Variables.size() == t_2.Variables.size()) {
			ArrayList<String> VariableMatching = new ArrayList<String>();
			for (int w = 0; w < t_1.Variables.size(); w++) {
				VariableMatching.add(t_1.Variables.get(w) + "/" + t_2.Variables.get(w));
			}
			return VariableMatching;
		} else
			return null;
	}

	/* This functions checks if the arraylist provided contains only atoms. */
	public static boolean checkAtoms(ArrayList<Atom> atoms) {
		for (int i = 0; i < atoms.size(); i++)
			if (!isAtom(atoms.get(i).toString()))
				return false;
		return true;
	}

	/*
	 * This is the Unify method. It returns the MGU in the form of arraylist if the
	 * set unifies.
	 */
	public static ArrayList<String> unify(ArrayList<Atom> atoms) {
		if (atoms.size() == 1)
			return null;
		ArrayList<String> E = new ArrayList<String>();
		ArrayList<String> S = new ArrayList<String>();
		String a;
		String b;
		String te = atoms.get(0).toString();
		for (int i = 1; i < atoms.size(); i++)
			te += "/" + atoms.get(i).toString();
		E.add(te);
		while (!E.isEmpty()) {
			String last = E.remove(E.size() - 1);
			String[] parts = last.split("\\s*/\\s*");
			a = parts[0];
			b = parts[1];
			if (!b.equals(a)) {
				if (isVariable(a)) {
					for (int i = 0; i < E.size(); i++) {
						String[] parts1 = E.get(i).split("\\s*/\\s*");
						String a1, b1;
						a1 = parts1[0].trim();
						b1 = parts1[1].trim();
						if (a1.equals(a))
							a1 = b;
						if (b1.equals(a))
							b1 = b;
						E.set(i, a1 + "/" + b1);
					}
					for (int i = 0; i < S.size(); i++) {
						String[] parts1 = S.get(i).split("\\s*/\\s*");
						String a1, b1;
						a1 = parts1[0].trim();
						b1 = parts1[1].trim();
						if (a1.equals(a))
							a1 = b;
						if (b1.equals(a))
							b1 = b;
						S.set(i, a1 + "/" + b1);
					}
					S.add(a + "/" + b);
				} else if (isVariable(b)) {
					for (int i = 0; i < E.size(); i++) {
						String[] parts1 = E.get(i).split("\\s*/\\s*");
						String a1, b1;
						a1 = parts1[0].trim();
						b1 = parts1[1].trim();
						if (a1.equals(b))
							a1 = a;
						if (b1.equals(b))
							b1 = a;
						E.set(i, a1 + "/" + b1);
					}
					for (int i = 0; i < S.size(); i++) {
						String[] parts1 = S.get(i).split("\\s*/\\s*");
						String a1, b1;
						a1 = parts1[0].trim();
						b1 = parts1[1].trim();
						if (a1.equals(b))
							a1 = a;
						if (b1.equals(b))
							b1 = a;
						S.set(i, a1 + "/" + b1);
					}
					S.add(b + "/" + a);
				} else if (isAtom(a) && checkAtoms(atoms)) {
					for (int i = 0; i < atoms.size() - 1; i++)
						for (int j = i + 1; j < atoms.size(); j++) {
							String atom1 = atoms.get(i).toString();
							String atom2 = atoms.get(j).toString();
							String name1 = atom1.substring(0, atom1.indexOf("("));
							String name2 = atom2.substring(0, atom2.indexOf("("));

							// Extract variables from each atom
							String variables1 = atom1.substring(atom1.indexOf("(") + 1, atom1.indexOf(")"));
							String variables2 = atom2.substring(atom2.indexOf("(") + 1, atom2.indexOf(")"));

							// Split variables by comma to count number of variables
							String[] vars1 = variables1.split(",");
							String[] vars2 = variables2.split(",");

							// Compare names and number of variables
							if (name1.equals(name2) && vars1.length == vars2.length) {
								for (int k = 0; k < vars1.length; k++) {
									E.add(vars1[k] + "/" + vars2[k]);
								}
							} else {
								return null;
							}
						}

				} else {
					return null;
				}
			}

		}

		return S;
	}

	/*
	 * This function checks whether a TGD s, is applicable to an atom A. Returns
	 * true if it is applicable.
	 */
	public static boolean isApplicable(Atom a, TGD s, ArrayList<String> sharedVar, ArrayList<String> constant) {
		ArrayList<Atom> set = new ArrayList<Atom>();
		set.add(a);
		set.add(s.head);
		if (unify(set) != null) {
			for (int i = 0; i < a.Variables.size(); i++) {
				if ((sharedVar.contains(a.Variables.get(i)) || constant.contains(a.Variables.get(i)))
						&& s.head.Variables.indexOf(s.ExistentiallyQuantifiedVar) == i)
					return false;
			}
			return true;
		} else
			return false;
	}

	/*
	 * This function checks whether a set is factorizable w.r.t to a TGD s. Returns
	 * true if the set is factorizable.
	 */
	public static boolean isFactorizable(ArrayList<Atom> Set, TGD s, Query q) {
		ArrayList<String> temporalVar = new ArrayList<String>();
		if (!Set.get(0).name.equals(s.head.name))
			return false;
		if (s.ExistentiallyQuantifiedVar == null)
			return false;
		ArrayList<Atom> set = new ArrayList<Atom>();
		set.addAll(Set);
		ArrayList<String> setUnifies = unify(set);
		if (setUnifies == null)
			return false;

		int ExistQuantVarPosition = s.head.Variables.indexOf(s.ExistentiallyQuantifiedVar);
		for (int w = 0; w < q.body.size(); w++) {
			if (!Set.contains(q.body.get(w)))
				temporalVar.addAll(q.body.get(w).Variables);
		}
		String Variable = Set.get(0).Variables.get(ExistQuantVarPosition);
		if (temporalVar.contains(Variable))
			return false;
		for (int w = 0; w < Set.size(); w++) {
			if (!((Set.get(w).Variables.indexOf(Variable) == Set.get(w).Variables.lastIndexOf(Variable))
					&& (Set.get(w).Variables.lastIndexOf(Variable) == ExistQuantVarPosition)))
				return false;

		}
		return true;
	}

	/*
	 * This function checks if the bodies of two queries are similar, meaning they
	 * have the same semantic query meaning, meaning they will return the same
	 * answers.
	 */
	public static ArrayList<ArrayList<Atom>> Similarity(ArrayList<Atom> qPrime, ArrayList<Atom> qQrew,
			ArrayList<ArrayList<Atom>> currentAssignment, HashMap<String, String> ModuloBijectiveVariables) {
		boolean notMerging = false;
		if (qPrime.isEmpty() && qQrew.isEmpty()) {
			return currentAssignment;
		}
		for (int w = 0; w < qPrime.size(); w++) {
			if (notMerging)
				return null;
			for (int q = 0; q < qQrew.size(); q++) {
				ArrayList<String> unifiedAtoms = checkVariables(qPrime.get(w), qQrew.get(q));
				if (unifiedAtoms != null) {
					ArrayList<String> currentlycheckingkeys = new ArrayList<String>();
					boolean notUnifying = false;
					for (int f = 0; f < unifiedAtoms.size(); f++) {
						String[] parts = unifiedAtoms.get(f).split("\\s*/\\s*");
						String a = parts[0].trim();
						String b = parts[1].trim();
						if ((isVariable(a) && isVariable(b)) || (!isVariable(a) && !isVariable(b) && a.equals(b))) {
							if (!ModuloBijectiveVariables.containsKey(a)) {
								if (!ModuloBijectiveVariables.containsValue(b)) {
									ModuloBijectiveVariables.put(a, b);
									currentlycheckingkeys.add(a);
								} else {
									String getKey = getKeyByValue(ModuloBijectiveVariables, b);
									if (!getKey.equals(a)) {
										for (int r = 0; r < currentlycheckingkeys.size(); r++) {
											ModuloBijectiveVariables.remove(currentlycheckingkeys.get(r));
										}
										notUnifying = true;
										break;
									}
								}
							} else {
								if (!ModuloBijectiveVariables.get(a).equals(b)) {
									for (int r = 0; r < currentlycheckingkeys.size(); r++) {
										ModuloBijectiveVariables.remove(currentlycheckingkeys.get(r));
									}
									notUnifying = true;
									break;
								}
							}
						} else {
							for (int r = 0; r < currentlycheckingkeys.size(); r++) {
								ModuloBijectiveVariables.remove(currentlycheckingkeys.get(r));
							}
							notUnifying = true;
							break;
						}
					}
					if (notUnifying) {
						notMerging = true;
						continue;
					}
					ArrayList<Atom> S = new ArrayList<Atom>();
					S.add(qPrime.get(w));
					S.add(qQrew.get(q));
					currentAssignment.add(S);
					notMerging = false;
					qPrime.remove(w);
					qQrew.remove(q);
					ArrayList<ArrayList<Atom>> result = Similarity(qPrime, qQrew, currentAssignment,
							ModuloBijectiveVariables);
					if (result == null) {
						qPrime.add(w, S.get(0));
						qQrew.add(q, S.get(1));
						currentAssignment.remove(S);
						for (int r = 0; r < currentlycheckingkeys.size(); r++) {
							ModuloBijectiveVariables.remove(currentlycheckingkeys.get(r));
						}
						notMerging = true;
						continue;
					} else
						return result;

				}

			}
		}

		return null;

	}

	/*
	 * The isSimilar function is used to iterate through all the queries of the Qrew
	 * set, and for each query in the Qrew set, the function similairt is used to
	 * determine if the newly produced Query Prime either coming from a
	 * factorization step or a rewriting step. Returns true if a query from Qrew, is
	 * similar, semantically equal to the query Prime.
	 */
	public static boolean isSimilar(ArrayList<XRewrite> Qrew, Query qPrime, String step) {
		ArrayList<Atom> temporalQueryqPrime = new ArrayList<Atom>();
		ArrayList<Atom> temporalQueryQrew = new ArrayList<Atom>();
		for (int q = 0; q < Qrew.size(); q++) {
			if (Qrew.get(q).rewriting || step.equals("factorizationStep")) {
				temporalQueryQrew.addAll(Qrew.get(q).q.body);
				temporalQueryqPrime.addAll(qPrime.body);
				if (temporalQueryQrew.size() == temporalQueryqPrime.size()) {
					ArrayList<ArrayList<Atom>> currentAssignment = new ArrayList<ArrayList<Atom>>();
					HashMap<String, String> ModuloBijectiveVariables = new HashMap<String, String>();
					for (int r = 0; r < qPrime.head.Variables.size(); r++) {
						String a = qPrime.head.Variables.get(r).toString();
						String b = Qrew.get(q).q.head.Variables.get(r).toString();
						if ((isVariable(a) && isVariable(b)) || (!isVariable(a) && !isVariable(b) && a.equals(b)))
							ModuloBijectiveVariables.put(a, b);
						else
							return false;
					}
					ArrayList<ArrayList<Atom>> result = Similarity(temporalQueryqPrime, temporalQueryQrew,
							currentAssignment, ModuloBijectiveVariables);
					if (result != null)
						return true;
				}
			} else {
				continue;
			}
			temporalQueryQrew.clear();
			temporalQueryqPrime.clear();
		}
		return false;

	}

	/* The rewritestep function applies a single rewrite to an atom w.r.t TGD s */
	public static HashMap<String, String> rewriteStep(Atom atom, TGD s, Query Q, int i) {
		ArrayList<Atom> atoms = new ArrayList<Atom>();
		atoms.add(s.head);
		atoms.add(atom);
		ArrayList<String> MGU = unify(atoms);
		HashMap<String, String> replacements = new HashMap<String, String>();
		HashMap<String, String> replacementsaux = new HashMap<String, String>();
		for (int q = 0; q < MGU.size(); q++) {
			String[] parts = MGU.get(q).split("\\s*/\\s*");
			String a = parts[0].trim();
			String b = parts[1].trim();
			if (s.ExistentiallyQuantifiedVar != null) {
				if (!s.ExistentiallyQuantifiedVar.equals(a))
					replacementsaux.put(a, b);
			} else
				replacementsaux.put(a, b);
		}

		Atom newbodyAtom = new Atom(s.body.toString());
		for (int q = 0; q < newbodyAtom.Variables.size(); q++) {
			if (replacementsaux.containsKey(newbodyAtom.Variables.get(q)))
				newbodyAtom.Variables.set(q, replacementsaux.get(newbodyAtom.Variables.get(q)));
			else
				newbodyAtom.Variables.set(q, newbodyAtom.Variables.get(q) + "_" + i);

		}
		Iterator<Map.Entry<String, String>> iterator = replacementsaux.entrySet().iterator();

		// Iterate through the HashMap using the Iterator
		while (iterator.hasNext()) {
			Map.Entry<String, String> entry = iterator.next();
			String key = entry.getKey();
			String value = entry.getValue();
			if (!replacements.containsKey(value) && (isVariable(value))
					&& (s.head.Variables.contains(key) && atom.Variables.contains(value)))
				if (s.ExistentiallyQuantifiedVar != null) {
					if (!s.ExistentiallyQuantifiedVar.equals(key))
						replacements.put(value, key + "_" + i);
				} else
					replacements.put(value, key + "_" + i);
		}
		iterator = replacementsaux.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<String, String> entry = iterator.next();
			String key = entry.getKey();
			String value = entry.getValue();
			if (atom.Variables.contains(key) && atom.Variables.contains(value) && replacements.containsKey(value))
				replacements.put(key, replacements.get(value));
		}

		for (int q = 0; q < newbodyAtom.Variables.size(); q++) {
			if (replacements.containsKey(newbodyAtom.Variables.get(q)))
				newbodyAtom.Variables.set(q, replacements.get(newbodyAtom.Variables.get(q)));
		}

		replacements.put("newAtom:", newbodyAtom.toString());

		return replacements;
	}

	/*
	 * Thia function unifies a set and returns the MGU for that set, along with an
	 * atom that is identical to all the atoms in the set. It is a representative
	 * atom for the set, that is identical to the rest atoms in the set.
	 */
	public static HashMap<String, String> unifyAtom(ArrayList<Atom> atoms) {
		HashMap<String, String> VariableSubstitution = new HashMap<String, String>();
		ArrayList<String> MGU = unify(atoms);
		if (MGU != null) {
			for (int f = 0; f < MGU.size(); f++) {
				String[] parts = MGU.get(f).split("\\s*/\\s*");
				String a = parts[0].trim();
				String b = parts[1].trim();
				VariableSubstitution.put(a, b);
			}
		} else {
			String newAtom = atoms.get(0).toString();
			Atom unifiedAtom = new Atom(newAtom);
			VariableSubstitution.put("unifiedAtom:", unifiedAtom.toString());
			return VariableSubstitution;
		}
		String newAtom = atoms.get(atoms.size() - 1).toString();
		Atom unifiedAtom = new Atom(newAtom);
		for (int i = 0; i < unifiedAtom.Variables.size(); i++)
			if (VariableSubstitution.containsKey(unifiedAtom.Variables.get(i)))
				unifiedAtom.Variables.set(i, VariableSubstitution.get(unifiedAtom.Variables.get(i)));
		VariableSubstitution.put("unifiedAtom:", unifiedAtom.toString());
		return VariableSubstitution;
	}
	/* This is the algorithm XRewrite. */

	public static void run(String optFlag, String file, String query) {
		readontology(file);
		readquery(query);
		int i = 0, k, eliminations = 0;
		XRewriteEliminate opt = new XRewriteEliminate();
		if (optFlag.equals("-qe")) {
			int counter = 0;
			opt = new XRewriteEliminate(ontology);
			List<Integer> eliminableAtoms = XRewriteEliminate.eliminateAlgorithm(queries.get(0));
			Iterator<Atom> iterator = queries.get(0).body.iterator();
			while (iterator.hasNext()) {
				iterator.next();
				if (eliminableAtoms.contains(counter)) {
					iterator.remove();
					eliminations++;
				}
				counter++;
			}
			String newBody = "";
			for (int w = 0; w < queries.get(0).body.size(); w++) {
				newBody += queries.get(0).body.get(w) + ",";
			}
			newBody = newBody.substring(0, newBody.length() - 1);
			queries.set(0, new Query(queries.get(0).head.toString(), newBody));
		}
		boolean joinedinaset = false;
		XRewrite firstQuery = new XRewrite(queries.get(0), true, false);
		Query QueryPrime;
		ArrayList<XRewrite> Qtemp = new ArrayList<XRewrite>();
		ArrayList<XRewrite> Qfin = new ArrayList<XRewrite>();
		ArrayList<XRewrite> Qrew = new ArrayList<XRewrite>();
		Qrew.add(firstQuery);

		do {
			Qtemp.removeAll(Qtemp);
			Qtemp.addAll(Qrew);
			for (k = 0; k < Qtemp.size(); k++) {
				if (!Qtemp.get(k).explored) {
					for (int j = 0; j < ontology.size(); j++) {
						/** Rewriting step **/
						ArrayList<ArrayList<Atom>> ApplicableSets = new ArrayList<ArrayList<Atom>>();
						ArrayList<ArrayList<Atom>> FactorizableSets = new ArrayList<ArrayList<Atom>>();

						for (int c = 0; c < Qtemp.get(k).q.body.size(); c++) {
							if (isApplicable(Qtemp.get(k).q.body.get(c), ontology.get(j), Qtemp.get(k).q.SharedVar,
									Qtemp.get(k).q.constant)) {
								if (!ApplicableSets.isEmpty()) {
									joinedinaset = false;
									for (int x = 0; x < ApplicableSets.size(); x++) {
										ArrayList<Atom> CandidateApplicableSet = new ArrayList<Atom>();
										CandidateApplicableSet.addAll(ApplicableSets.get(x));
										if (CandidateApplicableSet.contains(Qtemp.get(k).q.body.get(c))) {
											joinedinaset = true;
											continue;
										}
										CandidateApplicableSet.add(Qtemp.get(k).q.body.get(c));
										ArrayList<String> MGU = unify(CandidateApplicableSet);
										if (MGU != null) {
											ApplicableSets.set(x, CandidateApplicableSet);
											joinedinaset = true;
										}
									}
									if (!joinedinaset) {
										ArrayList<Atom> S = new ArrayList<Atom>();
										S.add(Qtemp.get(k).q.body.get(c));
										ApplicableSets.add(S);
										c = -1;
									}
								} else {
									ArrayList<Atom> S = new ArrayList<Atom>();
									S.add(Qtemp.get(k).q.body.get(c));
									ApplicableSets.add(S);
								}
							}
						}

						for (int q = 0; q < ApplicableSets.size(); q++) {

							i++;

							String newBody = "";
							for (int w = 0; w < Qtemp.get(k).q.body.size(); w++)
								if (!ApplicableSets.get(q).contains(Qtemp.get(k).q.body.get(w)))
									newBody += Qtemp.get(k).q.body.get(w).toString() + ",";
							HashMap<String, String> VariableSubstitution = new HashMap<String, String>();
							VariableSubstitution = unifyAtom(ApplicableSets.get(q));
							Atom unifiedAtom = new Atom(VariableSubstitution.remove("unifiedAtom:"));
							HashMap<String, String> ruleUnification = rewriteStep(unifiedAtom, ontology.get(j),
									Qtemp.get(k).q, i);

							newBody += ruleUnification.remove("newAtom:");

							QueryPrime = new Query(Qtemp.get(k).q.head.toString(), newBody);

							if (!VariableSubstitution.isEmpty()) {
								for (int r = 0; r < QueryPrime.head.Variables.size(); r++) {
									if (VariableSubstitution.get(QueryPrime.head.Variables.get(r)) != null)
										QueryPrime.head.Variables.set(r,
												VariableSubstitution.get(QueryPrime.head.Variables.get(r)));
								}

								for (int w = 0; w < QueryPrime.body.size(); w++) {
									for (int r = 0; r < QueryPrime.body.get(w).Variables.size(); r++)
										if (VariableSubstitution.get(QueryPrime.body.get(w).Variables.get(r)) != null)
											QueryPrime.body.get(w).Variables.set(r,
													VariableSubstitution.get(QueryPrime.body.get(w).Variables.get(r)));

								}
							}
							if (!ruleUnification.isEmpty()) {
								for (int r = 0; r < QueryPrime.head.Variables.size(); r++)
									if (ruleUnification.get(QueryPrime.head.Variables.get(r)) != null)
										QueryPrime.head.Variables.set(r,
												ruleUnification.get(QueryPrime.head.Variables.get(r)));

								for (int w = 0; w < QueryPrime.body.size(); w++)
									for (int r = 0; r < QueryPrime.body.get(w).Variables.size(); r++)
										if (ruleUnification.get(QueryPrime.body.get(w).Variables.get(r)) != null)
											QueryPrime.body.get(w).Variables.set(r,
													ruleUnification.get(QueryPrime.body.get(w).Variables.get(r)));
							}

							newBody = "";
							for (int w = 0; w < QueryPrime.body.size(); w++) {
								newBody += QueryPrime.body.get(w) + ",";
							}
							newBody = newBody.substring(0, newBody.length() - 1);
							QueryPrime = new Query(QueryPrime.head.toString(), newBody);

							if (optFlag.equals("-qe")) {
								int counter = 0;
								List<Integer> eliminableAtoms = XRewriteEliminate.eliminateAlgorithm(QueryPrime);
								Iterator<Atom> iterator = QueryPrime.body.iterator();
								while (iterator.hasNext()) {
									iterator.next();
									if (eliminableAtoms.contains(counter)) {
										iterator.remove(); // Remove the current element without moving indexes
										eliminations++;
									}
									counter++;
								}

								newBody = "";
								for (int w = 0; w < QueryPrime.body.size(); w++) {
									newBody += QueryPrime.body.get(w) + ",";
								}
								newBody = newBody.substring(0, newBody.length() - 1);
								QueryPrime = new Query(QueryPrime.head.toString(), newBody);
							}

							if (!isSimilar(Qrew, QueryPrime, "RewritingStep")) {
								Qrew.add(new XRewrite(QueryPrime, true, false));
							}
						}
						/** Rewriting step **/

						/** Factorization step **/

						if (Qtemp.get(k).q.body.size() >= 2 && ontology.get(j).ExistentiallyQuantifiedVar != null) {
							ArrayList<Integer> checked = new ArrayList<Integer>();
							for (int q = 0; q < Qtemp.get(k).q.body.size() - 1; q++) {
								if (!checked.contains(q)
										&& Qtemp.get(k).q.body.get(q).name.equals(ontology.get(j).head.name)
										&& isVariable(
												Qtemp.get(k).q.body.get(q).Variables.get(ontology.get(j).head.Variables
														.indexOf(ontology.get(j).ExistentiallyQuantifiedVar)))) {
									ArrayList<Atom> S = new ArrayList<Atom>();
									S.add(Qtemp.get(k).q.body.get(q));
									for (int w = q + 1; w < Qtemp.get(k).q.body.size(); w++) {
										if (candidateAtom(Qtemp.get(k).q.body.get(w), ontology.get(j), S.get(0))) {
											S.add(Qtemp.get(k).q.body.get(w));
											checked.add(w);
										}
									}
									if (S.size() > 1)
										if (isFactorizable(S, ontology.get(j), Qtemp.get(k).q))
											FactorizableSets.add(S);
								}
								if (!checked.contains(q))
									checked.add(q);
							}
						}

						for (int q = 0; q < FactorizableSets.size(); q++) {
							String newBody = "";
							for (int w = 0; w < Qtemp.get(k).q.body.size(); w++)
								if (!FactorizableSets.get(q).contains(Qtemp.get(k).q.body.get(w)))
									newBody += Qtemp.get(k).q.body.get(w).toString() + ",";

							HashMap<String, String> VariableReplacement = unifyAtom(FactorizableSets.get(q));

							newBody += VariableReplacement.remove("unifiedAtom:");

							QueryPrime = new Query(Qtemp.get(k).q.head.toString(), newBody);

							if (!VariableReplacement.isEmpty()) {
								for (int r = 0; r < QueryPrime.head.Variables.size(); r++) {
									if (VariableReplacement.get(QueryPrime.head.Variables.get(r)) != null)
										QueryPrime.head.Variables.set(r,
												VariableReplacement.get(QueryPrime.head.Variables.get(r)));
								}

								for (int w = 0; w < QueryPrime.body.size(); w++) {
									for (int r = 0; r < QueryPrime.body.get(w).Variables.size(); r++)
										if (VariableReplacement.get(QueryPrime.body.get(w).Variables.get(r)) != null)
											QueryPrime.body.get(w).Variables.set(r,
													VariableReplacement.get(QueryPrime.body.get(w).Variables.get(r)));

								}
							}

							newBody = "";
							for (int w = 0; w < QueryPrime.body.size(); w++) {
								newBody += QueryPrime.body.get(w) + ",";
							}
							newBody = newBody.substring(0, newBody.length() - 1);
							QueryPrime = new Query(QueryPrime.head.toString(), newBody);
							if (optFlag.equals("-qe")) {
								int counter = 0;
								List<Integer> eliminableAtoms = XRewriteEliminate.eliminateAlgorithm(QueryPrime);
								Iterator<Atom> iterator = QueryPrime.body.iterator();
								while (iterator.hasNext()) {
									iterator.next();
									if (eliminableAtoms.contains(counter)) {
										iterator.remove(); // Remove the current element without moving indexes
										eliminations++;
									}
									counter++;
								}
								newBody = "";
								for (int w = 0; w < QueryPrime.body.size(); w++) {
									newBody += QueryPrime.body.get(w) + ",";
								}
								newBody = newBody.substring(0, newBody.length() - 1);
								QueryPrime = new Query(QueryPrime.head.toString(), newBody);

							}
							if (!isSimilar(Qrew, QueryPrime, "factorizationStep"))
								Qrew.add(new XRewrite(QueryPrime, false, false));
						}

						/** Factorization step **/
					}
					Qrew.get(Qrew.indexOf(Qtemp.get(k))).explored = true;
				}
			}

		} while (!Qtemp.equals(Qrew));

		for (int a = 0; a < Qrew.size(); a++)
			if (Qrew.get(a).rewriting && Qrew.get(a).explored)
				Qfin.add(Qrew.get(a));

		for (int a = 0; a < Qfin.size(); a++)
			System.out.println("UCQ: " + Qfin.get(a).q.head.toString() + " :- " + UCQ(Qfin.get(a).q.body)
					+ "\nQuery shared variables: " + Qfin.get(a).q.SharedVar + "\n");
		System.out.println("UCQ size: " + Qfin.size());
		System.out.println("Number of Rewrites: " + i);
		System.out.println("Number of atoms that were eliminated: " + eliminations);

	}

	/*
	 * This is the main function that takes the arguments from the command line and
	 * analogously executes a mode of the algorithm, meaning if the user provides
	 * the -qe flag, then the algorithm will trigger the optimization technique of
	 * query elimination.
	 */
	public static void main(String[] args) {
		String fileName, optFlag, query;
		if (args.length == 3) {
			fileName = args[0];
			optFlag = args[1];
			query = args[2];
			long startTime = System.currentTimeMillis();
			long beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
			long beforeTotalMem = Runtime.getRuntime().totalMemory();
			run(optFlag, fileName, query);
			long endTime = System.currentTimeMillis();
			long afterUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
			long executionTime = (endTime - startTime);
			long actualMemUsed = afterUsedMem - beforeUsedMem;
			long afterTotalMem = Runtime.getRuntime().totalMemory();
			System.out.println("Size of ontology: " + ontology.size());
			System.out.println("Execution Time: " + executionTime);
			System.out.println("Memory used: " + actualMemUsed);
			System.out.println("Before Total memory:" + beforeTotalMem);
			System.out.println("After Total memory:" + afterTotalMem);
			System.out.println("New algorithm");
		} else if (args.length == 2) {
			fileName = args[0];
			query = args[1];
			long startTime = System.currentTimeMillis();
			long beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
			long beforeTotalMem = Runtime.getRuntime().totalMemory();
			run("", fileName, query);
			long endTime = System.currentTimeMillis();
			long afterUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
			long executionTime = (endTime - startTime);
			long actualMemUsed = afterUsedMem - beforeUsedMem;
			long afterTotalMem = Runtime.getRuntime().totalMemory();
			System.out.println("Size of ontology: " + ontology.size());
			System.out.println("Execution Time: " + executionTime);
			System.out.println("Memory used: " + actualMemUsed);
			System.out.println("Before Total memory:" + beforeTotalMem);
			System.out.println("After Total memory:" + afterTotalMem);
			
		} else {
			System.out.println(
					"Please give the correct input arguments! Example: <ontology file name> <-qe> <initial CQ q>. Note the flag <-qe> is optional.");
		}

	}

}
