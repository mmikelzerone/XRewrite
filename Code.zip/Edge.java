
public class Edge {
	public String node1;
	public String node2;
	public String tgd;

	/*
	 * This is a simple object Edge, which contains the edges that are part of the
	 * propagation graph.
	 */
	public Edge(String n1, String n2, String tgd) {
		this.node1 = n1;
		this.node2 = n2;
		this.tgd = tgd.toString();

	}
}
