import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Atom {
	String name;
	ArrayList<String> Variables = new ArrayList<String>();

	/*
	 * This is the constructor of the object Atom. When a string of the form
	 * "<relationname>(<term1>,<term2>,<term3>,..." is given as an input, the
	 * constructor breaks it down into the name part, the string, and into an
	 * arraylist of strings, that contain the variables and constants.
	 */
	public Atom(String atom) {
		this.name = atom.substring(0, atom.indexOf("("));
		Pattern pattern = Pattern.compile("\\((.*?)\\)");
		Matcher matcher = pattern.matcher(atom);
		if (matcher.find()) {
			String[] values = matcher.group(1).split(",");
			Variables.addAll(Arrays.asList(values));
		}
	}

	/* Returns the variables in order as one unified string. */
	public String Variables() {
		StringBuilder sb = new StringBuilder();
		for (String s : this.Variables) {
			sb.append(s);
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() - 1);
		return sb.toString();
	}

	/*
	 * Returns the string of the object Atom, a string of the form
	 * "<relationname>(<term1>,<term2>,<term3>,...".
	 */
	public String toString() {
		return this.name + "(" + Variables() + ")";
	}

}
