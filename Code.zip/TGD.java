import java.util.HashSet;
import java.util.Iterator;

public class TGD {
	Atom head;
	Atom body;
	String ExistentiallyQuantifiedVar;

	public TGD(String body, String head) {
		this.head = new Atom(head);
		this.body = new Atom(body);
		HashSet<String> variables = new HashSet<String>();
		variables.addAll(this.head.Variables);
		for (int i = 0; i < this.body.Variables.size(); i++) {
			if (variables.contains(this.body.Variables.get(i)))
				variables.remove(this.body.Variables.get(i));
		}
		Iterator<String> i = variables.iterator();
		if (variables.size() == 1)
			this.ExistentiallyQuantifiedVar = i.next();
		else
			this.ExistentiallyQuantifiedVar = null;

	}

	public String toString() {
		return this.head + " :- " + this.body;
	}

}
